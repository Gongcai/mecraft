# Mecraft ECS 架构深度剖析

## 目录

1. [架构总览](#架构总览)
2. [ECS 框架封装](#ecs-框架封装)
3. [双流水线架构](#双流水线架构)
4. [组件系统完整目录](#组件系统完整目录)
5. [系统详细分析](#系统详细分析)
6. [实体生命周期管理](#实体生命周期管理)
7. [客户端服务器分离](#客户端服务器分离)
8. [游戏外壳架构](#游戏外壳架构)
9. [性能优化策略](#性能优化策略)

---

## 架构总览

Mecraft 采用 **EnTT (Entity-Component-System)** 作为核心游戏逻辑框架，实现了高性能、数据驱动的游戏架构。整个架构的核心特点包括：

### 核心设计原则

1. **双流水线并行运行**
   - **fixedUpdate (60 Hz)**: 物理、动画、粒子、音频等实时响应系统
   - **tick (20 TPS)**: 世界模拟、流体、方块支撑等游戏逻辑系统

2. **客户端/服务器 Profile 分离**
   - 同一套 ECS 代码，根据 Profile 启用不同系统
   - 客户端运行渲染、输入、音频系统
   - 服务器运行权威物理、AI、战斗系统

3. **事件总线机制**
   - 伤害事件 (DamageEventBuffer)
   - 掉落物生成事件 (DropSpawnEventBuffer)
   - 粒子生成事件 (ParticleEventBuffer)
   - 音频事件 (AudioEventBuffer)
   - 下落方块生成事件 (FallingBlockEventBuffer)

4. **服务注入架构**
   - `GameplayServices` 提供外部服务的轻量级引用
   - `SystemContext` 统一传递上下文给所有系统

### 技术栈

- **ECS 库**: EnTT 3.x
- **数学库**: GLM (OpenGL Mathematics)
- **物理引擎**: 自研 PhysicsSystem (胶囊体碰撞 + Sweep & Prune)
- **网络同步**: 快照插值 + 客户端预测

---

## ECS 框架封装

### GameplayRegistry - EnTT 封装层

`GameplayRegistry` 是对 `entt::registry` 的轻量级封装，提供类型安全的接口和便捷方法。

#### 核心接口

```cpp
class GameplayRegistry {
public:
    // 实体管理
    entt::entity create();
    void destroy(entt::entity e);

    // 组件操作
    template<typename T, typename... Args>
    decltype(auto) emplace(entt::entity e, Args&&... args);

    template<typename T>
    T& get(entt::entity e);

    template<typename T>
    bool has(entt::entity e) const;

    template<typename T>
    T* try_get(entt::entity e);

    // 查询视图
    template<typename... Components>
    auto view();

    // 上下文/单例存储
    template<typename T, typename... Args>
    T& ctxSet(Args&&... args);

    template<typename T>
    T& ctxGet();

    template<typename T>
    bool ctxHas() const;

private:
    entt::registry m_registry;
};
```

#### 设计优势

1. **类型安全**: 所有接口返回强类型引用，避免裸指针
2. **上下文存储**: 利用 EnTT 的 `ctx()` 存储全局单例（如 `InputFrameState`、事件总线）
3. **简洁 API**: 隐藏 EnTT 复杂性，提供最常用的接口

### ISystem - 系统基类

所有游戏系统继承自 `ISystem` 抽象基类：

```cpp
class ISystem {
public:
    using Dependencies = NoSystemDependency;

    virtual ~ISystem() = default;
    virtual void update(SystemContext& ctx) = 0;
};
```

#### 系统依赖声明

每个系统可以声明其依赖的组件（用于调试验证）：

```cpp
class CharacterPhysicsSystem : public ISystem {
public:
    using Dependencies = SystemDependency<
        std::tuple<MoveIntentComponent, TransformComponent, PhysicsBodyComponent>,  // Required
        std::tuple<TransformComponent, PhysicsBodyComponent>                         // Written
    >;

    void update(SystemContext& ctx) override;
};
```

### SystemContext - 统一上下文

`SystemContext` 是传递给每个系统的统一上下文：

```cpp
struct SystemContext {
    GameplayRegistry& registry;   // ECS 注册表
    GameplayServices& services;   // 外部服务引用
    float dt = 0.0f;              // 固定时间步长或 tick 间隔
    uint64_t tickIndex = 0;       // 当前 tick 索引（仅 tick 流水线）
};
```

### GameplayServices - 服务注入

`GameplayServices` 使用 `OptionalService<T>` 包装外部服务引用：

```cpp
template <typename T>
class OptionalService {
public:
    T* get() const;
    T& require() const;           // Debug 模式下断言非空
    explicit operator bool() const;
    T* operator->() const;
    T& operator*() const;
};

struct GameplayServices {
    OptionalService<World>                   world;
    OptionalService<const IWorldView>        worldView;
    OptionalService<client::GameClient>      gameClient;
    OptionalService<AudioEngine>             audioEngine;
    OptionalService<InputContextManager>     inputContextManager;
    OptionalService<ResourceMgr>             resourceMgr;
    OptionalService<DropSystem>              dropSystem;
    OptionalService<ParticleSystem>          particleSystem;
    OptionalService<UIRenderer>              uiRenderer;
    OptionalService<physics::PhysicsSystem>  physicsSystem;
    OptionalService<CameraController>        cameraController;
};
```

#### 设计优势

- **延迟绑定**: 系统创建时不需要立即提供所有服务
- **类型安全**: 每个服务都有明确类型，避免 `void*`
- **Debug 友好**: `require()` 在 debug 模式下检查空指针

---

## 双流水线架构

Mecraft 的 ECS 采用双流水线设计，分别运行在不同频率：

### fixedUpdate 流水线 (60 Hz)

**目的**: 处理需要高频率更新的实时系统

**时间步长**: 固定 1/60 秒 (16.67ms)

**驱动方式**: 时间累积器 + 固定步长

```cpp
void Game::fixedUpdate(double fixedStep, double& accumulator) {
    accumulator -= fixedStep;
    
    // ... 输入采样、状态机更新 ...
    
    // ECS fixedUpdate 流水线
    session.gameplayScene().runFixedUpdate(static_cast<float>(fixedStep));
}
```

#### 客户端 fixedUpdate 系统顺序

```cpp
void GameplayPipeline::buildClientFixedUpdateSystems() {
    // ── Phase 1: 输入与玩家状态 ──
    addFixedUpdateSystem<InputSamplingSystem>();
    addFixedUpdateSystem<PlayerIntentBuildSystem>();
    addFixedUpdateSystem<MobAISystem>();
    addFixedUpdateSystem<CharacterPhysicsSystem>();
    addFixedUpdateSystem<PlayerRuntimeUpdateSystem>();
    addFixedUpdateSystem<FallDamageSystem>();
    addFixedUpdateSystem<ViewBobSystem>();

    // ── Phase 2: 交互与战斗 ──
    addFixedUpdateSystem<BlockTargetSystem>();
    addFixedUpdateSystem<PlayerMeleeSystem>();
    addFixedUpdateSystem<ProjectileSystem>();
    addFixedUpdateSystem<DamageSystem>(
        FixedUpdateDebugCategory::State,
        PostSystemHook::AfterDamageSystem  // Hook 点：网络同步伤害
    );
    addFixedUpdateSystem<HurtEffectDecaySystem>();
    addFixedUpdateSystem<DeathSystem>();
    addFixedUpdateSystem<BlockBreakSystem>();
    addFixedUpdateSystem<BlockPlaceSystem>();

    // ── Phase 3: 掉落物生命周期 ──
    addFixedUpdateSystem<ItemSpawnSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemPhysicsSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemMergeSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemPickupSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemLifetimeSystem>(FixedUpdateDebugCategory::Drop);

    // ── Phase 4: 粒子系统 ──
    addFixedUpdateSystem<ParticleSpawnSystem>(FixedUpdateDebugCategory::Particle);
    addFixedUpdateSystem<ParticleSimulationSystem>(FixedUpdateDebugCategory::Particle);
    addFixedUpdateSystem<ParticleCleanupSystem>(FixedUpdateDebugCategory::Particle);

    // ── Phase 5: 生存状态 ──
    addFixedUpdateSystem<HungerDepletionSystem>();

    // ── Phase 6: 音频与表现 ──
    addFixedUpdateSystem<PlayerFootstepAudioSystem>();
    addFixedUpdateSystem<FallRollEffectSystem>();
    addFixedUpdateSystem<AudioSyncSystem>();
    addFixedUpdateSystem<NetworkInterpolationSystem>();

    // ── Phase 7: 人形模型动画 ──
    addFixedUpdateSystem<SteveSyncSystem>();
    addFixedUpdateSystem<SteveAnimationSystem>();
    addFixedUpdateSystem<MobAnimationSystem>();
    addFixedUpdateSystem<TransformHierarchySystem>();

    // ── Phase 8: 下落方块渲染插值 ──
    addFixedUpdateSystem<FallingBlockInterpolateSystem>();
}
```

#### 服务器 fixedUpdate 系统顺序

服务器仅运行权威游戏逻辑，排除客户端特有系统：

```cpp
void GameplayPipeline::buildServerFixedUpdateSystems() {
    // 服务器只运行权威逻辑，不运行：
    // - InputSamplingSystem (客户端输入)
    // - BlockTargetSystem/BlockBreakSystem/BlockPlaceSystem (客户端交互)
    // - ParticleSystem (纯视觉效果)
    // - AudioSyncSystem (纯音频)
    // - SteveSyncSystem/Animation/Hierarchy (纯视觉层级)
    
    addFixedUpdateSystem<MobAISystem>();
    addFixedUpdateSystem<CharacterPhysicsSystem>();
    addFixedUpdateSystem<PlayerMeleeSystem>();
    addFixedUpdateSystem<ProjectileSystem>();
    addFixedUpdateSystem<DamageSystem>(
        FixedUpdateDebugCategory::State,
        PostSystemHook::AfterDamageSystem
    );
    addFixedUpdateSystem<HurtEffectDecaySystem>();
    addFixedUpdateSystem<DeathSystem>();
    addFixedUpdateSystem<ItemPhysicsSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemMergeSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemPickupSystem>(FixedUpdateDebugCategory::Drop);
    addFixedUpdateSystem<ItemLifetimeSystem>(FixedUpdateDebugCategory::Drop);
}
```

### tick 流水线 (20 TPS)

**目的**: 处理世界模拟、流体更新、方块支撑检测等低频逻辑

**时间步长**: 固定 1/20 秒 (50ms)

**驱动方式**: `GameTickClock` 累积器 + 固定步长

```cpp
void GameFrameOrchestrator::runFixedUpdate(...) {
    // ... fixedUpdate 流水线 ...
    
    // tick 流水线独立累积
    session.gameplayScene().tickClock().advance(scaledFixedStep);
    uint32_t ticksThisFrame = 0;
    while (session.gameplayScene().tickClock().shouldTick()
           && ticksThisFrame < session.gameplayScene().tickClock().maxTicksPerFrame()) {
        session.gameplayScene().runOneTick();
        session.gameplayScene().tickClock().consumeTick();
        ++ticksThisFrame;
    }
}
```

#### tick 系统顺序

```cpp
void GameplayPipeline::buildClientTickSystems() {
    addTickSystem<FluidTickSystem>();
    addTickSystem<BlockSupportSystem>();
    addTickSystem<FallingBlockSpawnSystem>();
    addTickSystem<FallingBlockTickSystem>();
}
```

#### tick 与 fixedUpdate 的协作

- **FluidTickSystem**: 每 tick 更新一次流体扩散
- **BlockSupportSystem**: 检测失去支撑的方块，发射 `FallingBlockSpawnEvent`
- **FallingBlockSpawnSystem**: 消费事件，生成下落方块实体
- **FallingBlockTickSystem**: 每 tick 移动下落方块一格（Minecraft 语义）
- **FallingBlockInterpolateSystem** (fixedUpdate): 在两个 tick 之间插值渲染位置

### 双流水线的时间管理

```cpp
class GameTickClock {
public:
    static constexpr double DEFAULT_TICK_RATE = 20.0;

    void advance(double deltaTime) {
        m_accumulator += deltaTime;
    }

    bool shouldTick() const {
        return m_accumulator >= m_tickInterval;
    }

    void consumeTick() {
        m_accumulator -= m_tickInterval;
        ++m_tickIndex;
    }

    uint64_t tickIndex() const { return m_tickIndex; }

private:
    double   m_tickInterval     = 1.0 / 20.0;  // 50ms
    double   m_accumulator      = 0.0;
    uint64_t m_tickIndex        = 0;
    uint32_t m_maxTicksPerFrame = 4;  // 防止死亡螺旋
};
```

### PostSystemHook - 系统后钩子

某些系统执行后需要立即触发网络同步或其他回调：

```cpp
enum class PostSystemHook : uint8_t {
    None,
    AfterDamageSystem  // 伤害系统执行后立即同步给网络层
};

struct GameplayPipelineHooks {
    std::function<void(SystemContext&)> afterDamageSystem;
};
```

**使用场景**:
- `DamageSystem` 执行后立即通知服务器，触发伤害网络同步
- 避免延迟一帧导致客户端不一致

---

## 组件系统完整目录

### 核心组件 (TransformComponents.h)

```cpp
struct TransformComponent {
    glm::vec3 position{0.0f};
    float eyeHeight = 1.62f;
};

struct ParentComponent {
    entt::entity parent = entt::null;
};

struct ChildrenComponent {
    std::vector<entt::entity> children;
};

struct LocalTransformComponent {
    glm::vec3 localPosition{0.0f};
    glm::vec3 localRotation{0.0f};  // Euler angles (degrees)
    glm::vec3 localScale{1.0f};

    glm::mat4 toMatrix() const;
};

struct WorldTransformComponent {
    glm::mat4 worldMatrix{1.0f};
};
```

**用途**:
- `TransformComponent`: 世界空间位置和眼睛高度
- `ParentComponent`/`ChildrenComponent`: 实体层级关系（如人形模型的骨骼）
- `LocalTransformComponent`: 局部变换（相对父节点）
- `WorldTransformComponent`: 世界变换矩阵（由 `TransformHierarchySystem` 计算）

### 物理组件 (PhysicsComponents.h)

```cpp
struct PhysicsBodyComponent {
    PhysicsBody body{};  // 胶囊体碰撞器
};

struct CharacterControllerComponent {
    PhysicsTuning tuning{};           // 加速度、摩擦力、跳跃高度等
    float standEyeHeight = 1.62f;
    float crouchEyeHeight = 1.0f;
    float eyeHeightLerpSpeed = 15.0f;
    bool crouchChangesEyeHeight = true;
};

struct FlightStateComponent {
    bool isFlying = false;
};

struct VelocityComponent {
    glm::vec3 velocity{0.0f};
};

struct BoundsComponent {
    glm::vec3 halfExtents{0.0f};
};

struct GroundedStateComponent {
    bool grounded = false;
};
```

**用途**:
- `PhysicsBodyComponent`: 持有物理引擎的 `PhysicsBody` 结构
- `CharacterControllerComponent`: 角色控制器特有参数（如蹲伏眼高）
- `FlightStateComponent`: 创造模式飞行状态
- `VelocityComponent`: 显式速度组件（用于网络同步）
- `BoundsComponent`: AABB 包围盒（用于掉落物、抛射物碰撞）
- `GroundedStateComponent`: 是否着地（用于音效、动画）

### 输入组件 (InputComponents.h)

```cpp
struct MoveIntentComponent {
    glm::vec2 move{0.0f};      // 世界空间 X/Z 移动意图
    bool wantsJump   = false;
    bool wantsSprint = false;
    bool wantsCrouch = false;
    bool toggleFlightMode = false;
};

struct LookIntentComponent {
    float deltaX = 0.0f;       // 水平鼠标增量
    float deltaY = 0.0f;       // 垂直鼠标增量
};

struct HotbarIntentComponent {
    bool slotSelected[9] = {}; // Hotbar1~9 触发
    bool scrollUp   = false;
    bool scrollDown = false;
};

struct BlockActionIntentComponent {
    bool wantsBreak = false;
    bool wantsPlace = false;
};
```

**用途**: 所有输入意图由 `InputSamplingSystem` 采样 → `PlayerIntentBuildSystem` 转换为世界空间意图

### 交互组件 (InteractionComponents.h)

```cpp
struct InventoryComponent {
    int selectedHotbarSlot = 0;
};

struct InventoryDataComponent {
    Inventory inventory;  // 背包实际数据
};

struct BlockTargetComponent {
    bool hasTarget = false;
    BlockID targetState = 0;
    glm::ivec3 targetBlock{};
    glm::ivec3 placeBlock{};
    glm::ivec3 hitNormal{};
};

struct BlockBreakComponent {
    bool active = false;
    glm::ivec3 blockPos{};
    float progress01 = 0.0f;  // 破坏进度（用于渲染裂纹）
};

struct BlockInteractionRuntimeComponent {
    float placeCooldownRemaining = 0.0f;
    float creativeBreakCooldownRemaining = 0.0f;
    bool breakActive = false;
    glm::ivec3 breakBlockPos{};
    float breakElapsedMs = 0.0f;
    float breakRequiredMs = 0.0f;
    glm::ivec3 recentlyPlacedBlock{};
    float postPlaceInteractionSuppressSeconds = 0.0f;
    uint32_t heldItemSwingSequence = 0;  // 客户端挥手动画序列号
};
```

**用途**:
- `BlockTargetComponent`: 玩家准星瞄准的方块信息
- `BlockBreakComponent`: 当前破坏方块的状态（用于渲染裂纹覆盖）
- `BlockInteractionRuntimeComponent`: 破坏/放置的运行时状态（冷却、进度）

### 战斗组件 (CombatComponents.h)

```cpp
struct MeleeAttackComponent {
    float cooldownRemaining = 0.0f;
    float cooldownSeconds = 0.45f;
    float reach = 3.25f;
    int damage = 4;
};

struct DropTableComponent {
    ItemID itemId = 0;
    uint32_t minCount = 1;
    uint32_t maxCount = 1;
    std::vector<DropTableEntry> entries;  // 支持多物品掉落
};

struct DamageEvent {
    entt::entity target = entt::null;
    entt::entity source = entt::null;
    int amount = 0;
};

struct DeathEffectComponent {
    BlockID particleBlock = 0;
    int particleCount = 24;
    std::string soundId;
    float volume = 1.0f;
};
```

**用途**:
- `MeleeAttackComponent`: 近战攻击参数（冷却、伤害、范围）
- `DropTableComponent`: 实体死亡时掉落物品配置
- `DamageEvent`: 伤害事件（通过 `DamageEventBuffer` 传递）
- `DeathEffectComponent`: 死亡时的粒子和音效

### 玩家状态组件 (PlayerStateComponents.h)

```cpp
struct HealthComponent {
    int current = 20;   // 0-20 (半颗心)
    int max = 20;
};

struct FoodComponent {
    int current = 20;   // 0-20 (半只鸡腿)
    int max = 20;
    int saturation = 5;
    double lastHungerTick = 0.0;  // 上次饥饿度消耗的游戏时间
};

struct ArmorComponent {
    int current = 0;    // 0-20
    int max = 20;
};

struct PlayerModeComponent {
    bool creative = false;
};

struct HurtEffectComponent {
    bool classicHurtEffectPending = false;
    float flashSecondsRemaining = 0.0f;
    float flashDurationSeconds = 0.18f;
    std::string soundId;
    float soundVolume = 1.0f;

    void triggerClassicHurt() {
        classicHurtEffectPending = true;
        flashSecondsRemaining = flashDurationSeconds;
    }
};

struct FootstepStateComponent {
    float timer = 0.0f;
    int clipIndex = 0;
};

struct LandingStateComponent {
    bool justLanded = false;
    float impactSpeed = 0.0f;
};

struct FallRollComponent {
    bool active = false;
    float elapsed = 0.0f;
    float currentRadians = 0.0f;
    static constexpr float kMaxRadians = 0.06f;
    static constexpr float kDurationSeconds = 0.24f;
    static constexpr float kPeakRatio = 0.35f;
};
```

**用途**:
- `HealthComponent`: 生命值（客户端和服务器同步）
- `FoodComponent`: 饥饿度（仅生存模式）
- `ArmorComponent`: 护甲值
- `PlayerModeComponent`: 创造/生存模式标识
- `HurtEffectComponent`: 受伤时的红屏闪烁和音效
- `FootstepStateComponent`: 脚步声计时器
- `LandingStateComponent`: 着地事件检测（用于摔落伤害）
- `FallRollComponent`: 着地时的相机翻滚效果

### 掉落物组件 (DropComponents.h)

```cpp
struct DropEntityIdComponent {
    std::size_t dropId = 0;  // 全局唯一 ID（用于网络同步）
};

struct ItemComponent {
    ItemID itemId = 0;
    uint32_t stackCount = 0;
};

struct LifetimeComponent {
    float ageSeconds = 0.0f;
    float lifeTimeSeconds = 0.0f;  // 30 秒后自动消失
};

struct SpinVisualComponent {
    float yawRadians = 0.0f;
    float spinSpeedRadians = 0.0f;
};

struct FallingBlockComponent {
    BlockID blockId = 0;
    glm::ivec3 gridPosition{};       // 当前逻辑格子位置
    glm::ivec3 prevGridPosition{};   // 上一个 tick 的格子位置（用于插值）
    float tickAccumulator = 0.0f;    // 渲染插值 alpha
};
```

**用途**:
- `DropEntityIdComponent`: 网络同步 ID（服务器分配）
- `ItemComponent`: 物品类型和堆叠数量
- `LifetimeComponent`: 掉落物年龄和生命周期
- `SpinVisualComponent`: 掉落物自旋动画
- `FallingBlockComponent`: 下落方块实体（沙子、沙砾）

### 抛射物组件 (ProjectileComponents.h)

```cpp
struct ProjectileDefinition {
    ItemID itemId = 0;
    int damage = 4;
    float hitRadius = 0.45f;
    float gravity = 8.0f;
    float throwSpeed = 15.0f;
    float upwardBias = 1.2f;
    float spawnForwardOffset = 0.75f;
    float boundsHalfExtent = 0.22f;
    float lifetimeSeconds = 4.0f;
    float spinSpeedRadians = 10.0f;
    BlockID entityImpactParticleBlock = 0;
    int entityImpactParticleCount = 14;
    std::string throwSoundId;
    std::string impactSoundId;
};

struct ProjectileComponent {
    entt::entity owner = entt::null;
    int damage = 4;
    float hitRadius = 0.45f;
    float gravity = 8.0f;
    BlockID entityImpactParticleBlock = 0;
    int entityImpactParticleCount = 14;
    std::string impactSoundId;
};

struct ProjectileThrowerComponent {
    float cooldownRemaining = 0.0f;
    float cooldownSeconds = 0.55f;
};

struct EntityImpactComponent {
    glm::vec3 position{0.0f};
    BlockID particleBlock = 0;
    int particleCount = 14;
};
```

**用途**:
- `ProjectileDefinition`: 抛射物的静态配置（如苹果抛射物）
- `ProjectileComponent`: 抛射物运行时参数
- `ProjectileThrowerComponent`: 投掷冷却
- `EntityImpactComponent`: 命中实体时的粒子效果

### 网络组件 (NetworkComponents.h)

```cpp
using EntityNetId = uint32_t;

enum class EntityKind : uint8_t {
    Drop = 0,
    Player = 1,
    Mob = 2,
};

struct EntityNetIdComponent {
    EntityNetId netId = 0;  // 服务器分配的网络 ID
};

struct NetworkSyncTag {};  // 标记需要网络同步的实体

struct EntityTypeComponent {
    std::string entityId;  // 稳定的实体类型 ID (如 "minecraft:zombie")
};

struct PendingNetworkDespawnTag {};  // 等待网络删除确认

struct NetworkSnapshotSample {
    uint32_t serverTick = 0;
    glm::vec3 position{0.0f};
    glm::vec3 velocity{0.0f};
    float yaw = 0.0f;
    float pitch = 0.0f;
};

struct NetworkInterpolationComponent {
    static constexpr std::size_t SnapshotBufferSize = 8;

    glm::vec3 targetPosition{0.0f};
    glm::vec3 targetVelocity{0.0f};
    float targetYaw = 0.0f;
    float targetPitch = 0.0f;
    float positionLerpSpeed = 12.0f;
    float rotationLerpSpeed = 16.0f;
    float snapDistance = 8.0f;          // 超过此距离直接传送
    float serverTickRate = 20.0f;
    float interpolationDelayTicks = 2.0f;  // 延迟 2 tick 插值（减少抖动）
    float renderServerTick = 0.0f;
    uint32_t latestServerTick = 0;
    std::array<NetworkSnapshotSample, SnapshotBufferSize> snapshots{};
    std::size_t snapshotCount = 0;
    bool hasRenderServerTick = false;
    bool hasTarget = false;
};
```

**用途**:
- `EntityNetIdComponent`: 服务器分配的全局唯一 ID
- `NetworkSyncTag`: 标记实体需要同步（如玩家、怪物、掉落物）
- `EntityTypeComponent`: 实体类型字符串（用于重新生成实体定义）
- `NetworkInterpolationComponent`: 客户端快照插值（平滑服务器权威位置）

### 人形模型组件 (SteveComponents.h)

```cpp
struct MobAIComponent {
    enum class State : uint8_t {
        Idle,
        Wander,
        Pursue,
        Attack
    };

    State state = State::Idle;
    entt::entity target = entt::null;
    float wanderTimer = 0.0f;
    float wanderInterval = 3.0f;
    glm::vec2 wanderDir{0.0f};
    float wanderSpeed = 0.45f;
    float pursueSpeed = 0.85f;
    float acquisitionRange = 14.0f;     // 发现玩家距离
    float loseTargetRange = 20.0f;      // 失去玩家距离
    float attackRange = 1.35f;
    float attackCooldownSeconds = 1.1f;
    float attackCooldownRemaining = 0.0f;
    int attackDamage = 3;
    float yaw = 0.0f;
};

struct MobVisualComponent {
    std::string model = "humanoid";
    std::string textureKey = "zombie";
    EntitySkinLayoutKind skinLayout = EntitySkinLayoutKind::Steve64x64;
    float scale = 1.0f;
};

enum class StevePartType : uint8_t {
    Torso,
    Head,
    RightArm,
    LeftArm,
    RightLeg,
    LeftLeg
};

struct StevePartComponent {
    StevePartType partType = StevePartType::Torso;
};

struct SteveAnimationStateComponent {
    float walkCyclePhase = 0.0f;
    float walkCycleSpeed = 8.0f;
    bool isWalking = false;
    bool isOnGround = true;
    glm::vec3 lastPosition{0.0f};
};
```

**用途**:
- `MobAIComponent`: 怪物 AI 状态机（闲逛、追逐、攻击）
- `MobVisualComponent`: 怪物外观配置（模型、纹理、布局）
- `StevePartComponent`: 人形模型部件标识（用于层级动画）
- `SteveAnimationStateComponent`: 行走动画状态

### 相机组件 (CameraComponents.h)

```cpp
struct CameraStateComponent {
    float yaw = -90.0f;
    float pitch = 0.0f;
    float fov = 75.0f;
    float sensitivity = 0.1f;
    glm::vec3 front{0.0f, 0.0f, -1.0f};
    glm::vec3 right{1.0f, 0.0f, 0.0f};
    glm::vec3 up{0.0f, 1.0f, 0.0f};
};

struct SprintFovComponent {
    float walkFov = 75.0f;
    float sprintFov = 90.0f;
    float lerpSpeed = 10.0f;
};

struct ViewBobComponent {
    float amplitude = 0.25f;
    float horizontalAmplitude = 0.02f;
    float frequency = 6.0f;
    float phaseOffset = 0.0f;
    float blend = 0.0f;
    float fadeInSpeed = 10.0f;
    float fadeOutSpeed = 8.0f;
    // 计算的偏移量（由 ViewBobSystem 写入，渲染代码读取）
    float verticalOffset = 0.0f;
    float horizontalOffset = 0.0f;
};
```

**用途**:
- `CameraStateComponent`: 相机方向和 FOV
- `SprintFovComponent`: 疾跑时 FOV 插值
- `ViewBobComponent`: 行走时相机摇晃效果

### 粒子组件 (ParticleComponents.h)

```cpp
struct ParticleComponent {
    float life = 0.0f;
    float maxLife = 0.0f;
    float size = 0.1f;
    float biomeTintFactor = 0.0f;  // 生物群系着色（如草地颜色）
    float layer = 0.0f;
    glm::vec2 uvMin{0.0f};
    glm::vec2 uvMax{1.0f};
};
```

**用途**: 粒子实体的生命周期和渲染参数

### 音频组件 (AudioComponents.h)

```cpp
struct AudioSourceComponent {
    std::string clipName;
    bool loop = false;
    float volume = 1.0f;
    float pitch = 1.0f;
    bool spatial = true;
    float referenceDistance = 8.0f;
    float rolloff = 1.0f;
    bool desiredPlaying = false;
    bool followTransform = true;
};
```

**用途**: 3D 空间音频源（如怪物的环境音效）

### 标签组件 (TagComponents.h)

```cpp
struct LocalPlayerTag {};
struct DropItemTag {};
struct ProjectileTag {};
struct FallingBlockTag {};
struct ParticleTag {};
struct SteveTag {};
struct MobTag {};
```

**用途**: 空标签组件，用于快速过滤特定实体类型

---

## 系统详细分析

### 输入与控制系统

#### InputSamplingSystem

**职责**: 采样输入管理器，将原始输入转换为 ECS 上下文

**执行时机**: fixedUpdate 第一个系统

**依赖服务**: `InputContextManager`

**核心逻辑**:

```cpp
void InputSamplingSystem::update(SystemContext& ctx) {
    if (!ctx.services.inputContextManager) return;
    auto& inputCtx = *ctx.services.inputContextManager;
    auto& frame = ctx.registry.ctxGet<InputFrameState>();

    // 轴输入
    frame.verticalAxis = inputCtx.getAxisValue(Axis::Vertical);
    frame.horizontalAxis = inputCtx.getAxisValue(Axis::Horizontal);
    frame.lookX = inputCtx.getAxisValue(Axis::LookX);
    frame.lookY = inputCtx.getAxisValue(Axis::LookY);

    // 动作输入
    frame.jump = inputCtx.isActionTriggered(Action::Jump);
    frame.jumpDoubleTap = inputCtx.isActionDoubleTapped(Action::Jump);
    frame.sprint = inputCtx.isActionTriggered(Action::Sprint);
    frame.crouch = inputCtx.isActionTriggered(Action::Crouch);
    frame.attack = inputCtx.isActionTriggered(Action::Attack);
    frame.useItem = inputCtx.isActionTriggered(Action::UseItem);

    // 快捷栏
    for (int i = 0; i < 9; ++i) {
        frame.hotbar[i] = inputCtx.isActionTriggered(
            static_cast<Action>(static_cast<int>(Action::Hotbar1) + i)
        );
    }
    frame.hotbarScrollUp = inputCtx.isActionTriggered(Action::HotbarScrollUp);
    frame.hotbarScrollDown = inputCtx.isActionTriggered(Action::HotbarScrollDown);

    // 上下文
    frame.gameplayContextActive = (inputCtx.getCurrentContext() == InputContextType::Gameplay);
}
```

**设计亮点**:
- 将输入存储在 ECS 上下文 `InputFrameState` 中，避免全局变量
- 所有系统都可以通过 `ctx.registry.ctxGet<InputFrameState>()` 访问输入
- 双击检测（双击跳跃进入飞行模式）

#### PlayerIntentBuildSystem

**职责**: 将原始输入转换为世界空间移动意图

**执行时机**: fixedUpdate 第二个系统

**查询的组件**: `LocalPlayerTag`, `MoveIntentComponent`, `LookIntentComponent`, `HotbarIntentComponent`, `BlockActionIntentComponent`, `CameraStateComponent`

**核心逻辑**:

```cpp
void PlayerIntentBuildSystem::update(SystemContext& ctx) {
    const InputFrameState& frame = ctx.registry.ctxGet<InputFrameState>();
    
    if (!frame.gameplayContextActive) {
        // UI 打开时清空所有意图
        for (auto e : view) {
            auto& move = view.get<MoveIntentComponent>(e);
            // ... 清空所有意图 ...
        }
        return;
    }

    for (auto e : view) {
        if (玩家已死亡) {
            // 清空意图
            continue;
        }

        const auto& camera = view.get<CameraStateComponent>(e);
        auto& move = view.get<MoveIntentComponent>(e);

        // 将相机前向和右向投影到水平面
        glm::vec3 front = camera.front;
        glm::vec3 right = camera.right;
        front.y = 0.0f;
        right.y = 0.0f;
        front = glm::normalize(front);
        right = glm::normalize(right);

        // 计算世界空间移动方向
        glm::vec3 wishDir = front * frame.verticalAxis + right * frame.horizontalAxis;
        if (glm::length(wishDir) > 0.001f) {
            wishDir = glm::normalize(wishDir);
        }

        move.move = glm::vec2(wishDir.x, wishDir.z);
        move.wantsJump = frame.jump;
        move.wantsSprint = frame.sprint;
        move.wantsCrouch = frame.crouch;
        move.toggleFlightMode = frame.jumpDoubleTap;

        // 手柄输入灵敏度补偿
        const bool likelyGamepad = (std::abs(frame.lookX) <= 1.5f && std::abs(frame.lookY) <= 1.5f);
        if (likelyGamepad) {
            look.deltaX = frame.lookX * 50.0f;
            look.deltaY = frame.lookY * 50.0f;
        } else {
            look.deltaX = frame.lookX;
            look.deltaY = frame.lookY;
        }

        // ... 快捷栏和方块交互意图 ...
    }
}
```

**设计亮点**:
- 将相机空间输入转换为世界空间移动
- 支持手柄和鼠标键盘（自动检测并调整灵敏度）
- 死亡时自动清空意图

### 物理与移动系统

#### CharacterPhysicsSystem

**职责**: 驱动角色控制器物理（AABB 碰撞 + Sweep & Prune）

**执行时机**: fixedUpdate

**查询的组件**: `MoveIntentComponent`, `TransformComponent`, `PhysicsBodyComponent`, `CharacterControllerComponent`

**核心逻辑**:

```cpp
void CharacterPhysicsSystem::update(SystemContext& ctx) {
    if (!ctx.services.physicsSystem) return;
    auto& physicsSystem = *ctx.services.physicsSystem;

    auto view = ctx.registry.view<MoveIntentComponent, TransformComponent, PhysicsBodyComponent>();
    for (const auto entity : view) {
        auto& moveIntent = view.get<MoveIntentComponent>(entity);
        auto& transform = view.get<TransformComponent>(entity);
        auto& physicsBody = view.get<PhysicsBodyComponent>(entity);
        auto* controller = ctx.registry.try_get<CharacterControllerComponent>(entity);
        auto* flightState = ctx.registry.try_get<FlightStateComponent>(entity);

        const bool wasGrounded = physicsBody.body.isGrounded;
        bool isFlying = flightState && flightState->isFlying;

        // 创造模式飞行切换
        if (flightState && moveIntent.toggleFlightMode && 创造模式) {
            flightState->isFlying = !flightState->isFlying;
            physicsBody.body.velocity.y = 0.0f;  // 清空垂直速度
        }

        // 同步 Transform 到 PhysicsBody
        physicsBody.body.position = transform.position;
        physicsBody.body.eyeOffsetY = transform.eyeHeight;

        // 调用物理引擎更新
        if (controller) {
            physicsSystem.updateBody(physicsBody.body, toLegacyIntent(moveIntent, isFlying), dt, controller->tuning);
            updateEyeHeight(moveIntent, isFlying, physicsBody, *controller, transform, dt);
        } else {
            physicsSystem.updateBody(physicsBody.body, toLegacyIntent(moveIntent, isFlying), dt);
        }

        // 同步 PhysicsBody 回 Transform
        transform.position = physicsBody.body.position;

        // 着地检测
        if (auto* landing = ctx.registry.try_get<LandingStateComponent>(entity)) {
            landing->justLanded = (physicsBody.body.isGrounded && !wasGrounded);
            landing->impactSpeed = landing->justLanded ? physicsBody.body.landingImpactSpeed : 0.0f;
        }

        // 同步着地状态
        if (auto* grounded = ctx.registry.try_get<GroundedStateComponent>(entity)) {
            grounded->grounded = physicsBody.body.isGrounded;
        }

        // 同步速度组件
        if (auto* velocity = ctx.registry.try_get<VelocityComponent>(entity)) {
            velocity->velocity = physicsBody.body.velocity;
        }
    }
}
```

**设计亮点**:
- 双向同步 `TransformComponent` ↔ `PhysicsBodyComponent`
- 支持飞行模式（创造模式）
- 蹲伏时眼高平滑插值
- 着地事件检测（用于摔落伤害和音效）


#### ItemPhysicsSystem

**职责**: 掉落物物理模拟（重力、碰撞、摩擦）

**执行时机**: fixedUpdate (Drop 分类)

**查询的组件**: `DropItemTag`, `TransformComponent`, `VelocityComponent`, `BoundsComponent`, `SpinVisualComponent`, `GroundedStateComponent`

**核心逻辑**:

```cpp
void ItemPhysicsSystem::update(SystemContext& ctx) {
    auto view = ctx.registry.view<DropItemTag, TransformComponent, VelocityComponent, 
                                   BoundsComponent, SpinVisualComponent, GroundedStateComponent>();
    for (const entt::entity e : view) {
        auto& transform = view.get<TransformComponent>(e);
        auto& velocity = view.get<VelocityComponent>(e);
        auto& spin = view.get<SpinVisualComponent>(e);
        auto& grounded = view.get<GroundedStateComponent>(e);

        // 自旋动画
        spin.yawRadians = std::fmod(spin.yawRadians + spin.spinSpeedRadians * dt, TWO_PI);
        
        // 重力
        velocity.velocity.y = std::max(velocity.velocity.y - 20.0f * dt, -25.0f);  // 终端速度
        
        // 分轴碰撞检测（Y -> X -> Z）
        drop_detail::moveAndCollideAxis(transform, velocity, bounds, grounded, world, 1, dt);  // Y
        drop_detail::moveAndCollideAxis(transform, velocity, bounds, grounded, world, 0, dt);  // X
        drop_detail::moveAndCollideAxis(transform, velocity, bounds, grounded, world, 2, dt);  // Z
        
        // 摩擦力
        if (grounded.grounded) {
            velocity.velocity.x *= 0.86f;  // 地面摩擦
            velocity.velocity.z *= 0.86f;
        } else {
            velocity.velocity.x *= 0.92f;  // 空气阻力
            velocity.velocity.z *= 0.92f;
        }
    }
}
```

**设计亮点**:
- 分轴碰撞检测避免隧穿
- 着地时高摩擦，空中时低阻力
- 自旋动画独立于物理


### 战斗系统

#### MobAISystem

**职责**: 怪物 AI 状态机（闲逛、追逐、攻击）

**执行时机**: fixedUpdate

**查询的组件**: `MobTag`, `TransformComponent`, `MobAIComponent`, `MoveIntentComponent`

**核心逻辑**:

```cpp
void MobAISystem::update(SystemContext& ctx) {
    auto view = ctx.registry.view<MobTag, TransformComponent, MobAIComponent, MoveIntentComponent>();
    for (auto entity : view) {
        auto& ai = view.get<MobAIComponent>(entity);
        auto& moveIntent = view.get<MoveIntentComponent>(entity);
        
        ai.attackCooldownRemaining = std::max(0.0f, ai.attackCooldownRemaining - dt);
        ai.wanderTimer -= dt;
        
        // 目标有效性检查
        if (!isTargetUsable(ai.target, transform.position, ai.loseTargetRange)) {
            ai.target = findNearestTarget(transform.position, ai.acquisitionRange);
        }
        
        if (ai.target != entt::null) {
            // 追逐或攻击玩家
            glm::vec2 toTarget = 计算水平方向向量;
            float distance = glm::length(toTarget);
            ai.yaw = yawFromMove(toTarget);
            
            if (distance <= ai.attackRange) {
                ai.state = MobAIComponent::State::Attack;
                if (ai.attackCooldownRemaining <= 0.0f) {
                    ensureDamageEventBus(registry).push({ai.target, entity, ai.attackDamage});
                    ai.attackCooldownRemaining = ai.attackCooldownSeconds;
                }
            } else {
                ai.state = MobAIComponent::State::Pursue;
                moveIntent.move = toTarget * ai.pursueSpeed;
            }
        } else {
            // 闲逛
            if (ai.wanderTimer <= 0.0f) {
                chooseWanderDirection(ai);  // 随机方向或静止
            }
            moveIntent.move = ai.wanderDir * ai.wanderSpeed;
        }
    }
}
```

**状态转换图**:

```
    Idle ──(发现玩家)──> Pursue ──(距离 <= 攻击范围)──> Attack
      ↑                      |                              |
      └──(失去目标)───────────┴──────────────────────────────┘
```

**设计亮点**:
- 目标获取使用范围查询（`acquisitionRange`）
- 目标丢失使用更大范围（`loseTargetRange`，防止抖动）
- 攻击使用伤害事件总线，解耦攻击和伤害处理


#### DamageSystem

**职责**: 处理伤害事件总线，应用伤害到实体

**执行时机**: fixedUpdate (带 PostSystemHook)

**查询的组件**: 从 `DamageEventBus` 读取事件

**核心逻辑**:

```cpp
void DamageSystem::update(SystemContext& ctx) {
    auto& damageBus = ctx.registry.ctxGet<DamageEventBus>();
    
    for (const DamageEvent& event : damageBus.events) {
        if (event.amount <= 0 || !reg.valid(event.target)) continue;
        
        // 创造模式玩家免疫伤害
        if (isCreativeLocalPlayer(registry, event.target)) continue;
        
        auto* health = reg.try_get<HealthComponent>(event.target);
        if (!health || health->current <= 0) continue;
        
        // 应用伤害
        health->current = std::max(0, health->current - event.amount);
        
        // 触发受伤效果
        if (auto* hurt = reg.try_get<HurtEffectComponent>(event.target)) {
            hurt->triggerClassicHurt();  // 红屏闪烁
            queueHurtAudio(ctx, event.target, *hurt);
        }
    }
    
    damageBus.clear();
}
```

**设计亮点**:
- 事件总线解耦伤害源和伤害处理
- 创造模式免疫检查
- 伤害应用后立即触发视觉/音频反馈
- PostSystemHook 允许网络层立即同步伤害

#### DeathSystem

**职责**: 处理实体死亡（生命值归零）

**执行时机**: fixedUpdate (DamageSystem 之后)

**查询的组件**: `HealthComponent`

**核心逻辑**:

```cpp
void DeathSystem::update(SystemContext& ctx) {
    auto view = ctx.registry.view<HealthComponent>();
    for (auto entity : view) {
        auto& health = view.get<HealthComponent>(entity);
        if (health.current > 0) continue;
        
        // 生成死亡粒子
        if (auto* deathEffect = reg.try_get<DeathEffectComponent>(entity)) {
            auto& particleBus = ensureParticleEventBus(registry);
            particleBus.push({transform.position, deathEffect->particleBlock, deathEffect->particleCount});
        }
        
        // 播放死亡音效
        if (auto* deathEffect = reg.try_get<DeathEffectComponent>(entity)) {
            auto& audioBus = ensureAudioEventBus(registry);
            audioBus.push({deathEffect->soundId, transform.position, true, deathEffect->volume});
        }
        
        // 生成掉落物
        if (auto* dropTable = reg.try_get<DropTableComponent>(entity)) {
            auto& dropBus = ensureDropSpawnEventBus(registry);
            for (const auto& entry : dropTable->entries) {
                uint32_t count = randomInRange(entry.minCount, entry.maxCount);
                dropBus.push({entry.itemId, count, transform.position});
            }
        }
        
        // 删除实体
        if (reg.all_of<LocalPlayerTag>(entity)) {
            // 本地玩家不删除，等待重生
        } else {
            ctx.registry.destroy(entity);
        }
    }
}
```

**设计亮点**:
- 统一处理所有实体死亡（玩家、怪物、掉落物）
- 通过事件总线生成粒子和音效
- 掉落表支持多物品随机掉落


### 方块交互系统

#### BlockTargetSystem

**职责**: 射线检测玩家准星瞄准的方块

**执行时机**: fixedUpdate

**查询的组件**: `LocalPlayerTag`, `TransformComponent`, `CameraStateComponent`, `BlockTargetComponent`

#### BlockBreakSystem

**职责**: 处理方块破坏（生存模式进度、创造模式瞬间破坏）

**执行时机**: fixedUpdate

**查询的组件**: `LocalPlayerTag`, `BlockActionIntentComponent`, `BlockTargetComponent`, `BlockBreakComponent`, `BlockInteractionRuntimeComponent`, `TransformComponent`

**核心逻辑**:

```cpp
void BlockBreakSystem::update(SystemContext& ctx) {
    for (auto e : view) {
        auto& runtime = view.get<BlockInteractionRuntimeComponent>(e);
        const auto& intent = view.get<BlockActionIntentComponent>(e);
        const auto& target = view.get<BlockTargetComponent>(e);
        
        // 冷却递减
        runtime.creativeBreakCooldownRemaining = std::max(0.0f, runtime.creativeBreakCooldownRemaining - dt);
        
        if (!intent.wantsBreak || !target.hasTarget) {
            resetBreakSession(blockBreak, runtime);
            continue;
        }
        
        // 距离验证（防止作弊）
        if (distanceToBlock > 6.5f) {
            resetBreakSession(blockBreak, runtime);
            continue;
        }
        
        if (!modeRules.shouldReportBreakProgress()) {
            // 创造模式瞬间破坏
            if (runtime.creativeBreakCooldownRemaining > 0.0f) continue;
            
            if (mutableWorld) {
                mutableWorld->setBlock(hitBlock, 0);
                handleChestInventoryBreak(registry, brokenBlock, hitBlock, false);
                audioBus.push({"block.generic.break", glm::vec3(hitBlock), true, 1.0f});
                particleBus.push({hitBlock, brokenBlock});
            } else {
                // 客户端发送破坏请求到服务器
                ctx.services.gameClient->sendBlockAction(action);
            }
            
            runtime.creativeBreakCooldownRemaining = 0.15f;
            resetBreakSession(blockBreak, runtime);
        } else {
            // 生存模式渐进破坏
            if (!runtime.breakActive || runtime.breakBlockPos != hitBlock) {
                runtime.breakActive = true;
                runtime.breakBlockPos = hitBlock;
                runtime.breakElapsedMs = 0.0f;
                runtime.breakRequiredMs = modeRules.breakDurationMs(targetBlock);
            }
            
            runtime.breakElapsedMs += dt * 1000.0f;
            blockBreak.progress01 = std::clamp(runtime.breakElapsedMs / runtime.breakRequiredMs, 0.0f, 1.0f);
            
            if (runtime.breakElapsedMs >= runtime.breakRequiredMs) {
                // 完成破坏
                if (mutableWorld) {
                    mutableWorld->setBlock(hitBlock, 0);
                    dropBus.push({brokenBlock, hitBlock});  // 生存模式掉落方块
                    audioBus.push({"block.generic.break", glm::vec3(hitBlock), true, 1.0f});
                    particleBus.push({hitBlock, brokenBlock});
                } else {
                    ctx.services.gameClient->sendBlockAction(action);
                }
                resetBreakSession(blockBreak, runtime);
            }
        }
    }
}
```

**设计亮点**:
- 创造/生存模式不同破坏逻辑
- 距离验证防止作弊
- 客户端预测 + 服务器权威验证
- 破坏进度实时更新（用于渲染裂纹）


### 网络同步系统

#### NetworkInterpolationSystem

**职责**: 客户端快照插值（平滑服务器权威位置）

**执行时机**: fixedUpdate

**查询的组件**: `NetworkInterpolationComponent`, `TransformComponent`

**核心逻辑**:

```cpp
void NetworkInterpolationSystem::update(SystemContext& ctx) {
    auto view = ctx.registry.view<NetworkInterpolationComponent, TransformComponent>();
    for (const entt::entity entity : view) {
        auto& interpolation = view.get<NetworkInterpolationComponent>(entity);
        if (!interpolation.hasTarget) continue;
        
        auto& transform = view.get<TransformComponent>(entity);
        SampledPose pose;
        
        if (sampleSnapshotBuffer(interpolation, ctx.dt, pose)) {
            // 使用快照缓冲区插值
            transform.position = pose.position;
            if (auto* spin = reg.try_get<SpinVisualComponent>(entity)) {
                spin->yawRadians = lerpAngleRadians(pose.yawFrom, pose.yawTo, pose.alpha);
            }
            if (auto* mobAI = reg.try_get<MobAIComponent>(entity)) {
                mobAI->yaw = lerpAngleDegrees(pose.yawFrom, pose.yawTo, pose.alpha);
            }
        } else {
            // 回退到目标位置插值
            applyFallbackTarget(reg, entity, transform, interpolation, ctx.dt);
        }
    }
}
```

**快照缓冲区采样**:

```cpp
bool sampleSnapshotBuffer(NetworkInterpolationComponent& interpolation, float dt, SampledPose& outPose) {
    if (interpolation.snapshotCount < 2) return false;
    
    const auto& oldest = interpolation.snapshots[0];
    const auto& newest = interpolation.snapshots[snapshotCount - 1];
    
    // 延迟插值（减少网络抖动）
    const float delayedNewestTick = newestTick - interpolation.interpolationDelayTicks;
    
    // 推进渲染 tick
    if (!interpolation.hasRenderServerTick) {
        interpolation.renderServerTick = delayedNewestTick;
        interpolation.hasRenderServerTick = true;
    } else {
        float advancedRenderTick = previousRenderTick + interpolation.serverTickRate * dt;
        interpolation.renderServerTick = std::min(advancedRenderTick, delayedNewestTick);
    }
    
    // 在快照缓冲区中查找包含 renderServerTick 的区间
    for (size_t i = 1; i < snapshotCount; ++i) {
        const auto& a = interpolation.snapshots[i - 1];
        const auto& b = interpolation.snapshots[i];
        if (renderServerTick > b.serverTick) continue;
        
        float alpha = (renderServerTick - a.serverTick) / (b.serverTick - a.serverTick);
        
        // 距离过大时直接传送
        if (glm::length(b.position - a.position) > interpolation.snapDistance) {
            outPose.position = a.position;
            outPose.alpha = 0.0f;
        } else {
            outPose.position = a.position + (b.position - a.position) * alpha;
            outPose.alpha = alpha;
        }
        
        outPose.yawFrom = a.yaw;
        outPose.yawTo = b.yaw;
        return true;
    }
    return false;
}
```

**设计亮点**:
- 延迟 2 tick 插值（减少网络抖动）
- 快照缓冲区支持最多 8 个快照
- 距离过大时直接传送（防止穿墙）
- 角度使用最短路径插值（避免 360° 旋转）


---

## 实体生命周期管理

### 实体工厂 (EntityFactory)

`EntityFactory` 提供静态方法创建各种实体类型：

#### 玩家代理实体

```cpp
entt::entity EntityFactory::createServerPlayerProxy(GameplayRegistry& registry,
                                                    const glm::vec3& position,
                                                    const glm::vec3& velocity) {
    entt::entity entity = registry.create();
    ensureServerPlayerProxy(registry, entity, position, velocity);
    return entity;
}

void EntityFactory::ensureServerPlayerProxy(GameplayRegistry& registry,
                                            entt::entity entity,
                                            const glm::vec3& position,
                                            const glm::vec3& velocity) {
    ensureComponent<LocalPlayerTag>(reg, entity);
    auto& transform = ensureComponentRef<TransformComponent>(reg, entity, position, 1.62f);
    auto& velocityComponent = ensureComponentRef<VelocityComponent>(reg, entity);
    velocityComponent.velocity = velocity;
    
    ensureComponent<CameraStateComponent>(reg, entity);
    ensureComponent<BlockActionIntentComponent>(reg, entity);
    ensureComponent<BlockTargetComponent>(reg, entity);
    ensureComponent<BlockInteractionRuntimeComponent>(reg, entity);
    ensureComponent<MeleeAttackComponent>(reg, entity);
    ensureComponent<ProjectileThrowerComponent>(reg, entity);
    ensureComponent<HealthComponent>(reg, entity);
    ensureComponent<PlayerModeComponent>(reg, entity);
    ensureComponent<HurtEffectComponent>(reg, entity);
    ensureComponent<InventoryComponent>(reg, entity);
    
    if (!reg.all_of<InventoryDataComponent>(entity)) {
        auto& inventoryData = reg.emplace<InventoryDataComponent>(entity);
        inventoryData.inventory.initializeDefaultLoadout();
    }
}
```

**用途**: 多人游戏客户端接收服务器玩家实体时创建

#### 怪物实体

```cpp
entt::entity EntityFactory::createMob(GameplayRegistry& registry,
                                      std::string_view entityId,
                                      const glm::vec3& position) {
    // 加载实体定义
    const MobEntityDefinition* definition = EntityDefinitionRegistry::instance().findMob(entityId);
    
    // 根据模型类型创建骨架
    entt::entity entity = entt::null;
    if (definition->model == "humanoid") {
        entity = MobModelFactory::createHumanoidMob(registry, position);
    }
    
    // 应用定义参数
    applyMobDefinition(registry, entity, *definition);
    return entity;
}
```

**实体定义系统**: 从 JSON 文件加载怪物配置（血量、AI 参数、掉落表、模型等）

#### 掉落物实体

```cpp
entt::entity EntityFactory::createItemDrop(GameplayRegistry& registry,
                                           const ItemDropSpawnParams& params) {
    auto& state = ensureDropRuntimeState(registry);
    const std::size_t dropId = params.dropId != 0 ? params.dropId : state.nextId++;
    
    const entt::entity drop = reg.create();
    reg.emplace<DropItemTag>(drop);
    reg.emplace<DropEntityIdComponent>(drop, dropId);
    reg.emplace<TransformComponent>(drop, params.position, 0.0f);
    reg.emplace<VelocityComponent>(drop, params.velocity);
    reg.emplace<ItemComponent>(drop, params.itemId, params.stackCount);
    reg.emplace<BoundsComponent>(drop, params.halfExtents);
    reg.emplace<LifetimeComponent>(drop, params.ageSeconds, params.lifeTimeSeconds);
    reg.emplace<SpinVisualComponent>(drop, params.yawRadians, params.spinSpeedRadians);
    reg.emplace<GroundedStateComponent>(drop, GroundedStateComponent{params.grounded});
    reg.emplace<NetworkSyncTag>(drop);
    return drop;
}
```

**设计亮点**:
- 全局唯一 `dropId`（用于网络同步）
- 30 秒生命周期（`LifetimeComponent`）
- 自动标记 `NetworkSyncTag`

#### 下落方块实体

```cpp
entt::entity EntityFactory::createFallingBlock(GameplayRegistry& registry,
                                               const FallingBlockSpawnParams& params) {
    const entt::entity entity = reg.create();
    const glm::vec3 renderPos = glm::vec3(params.gridPosition) + glm::vec3(0.5f);
    
    reg.emplace<FallingBlockTag>(entity);
    reg.emplace<FallingBlockComponent>(entity,
                                       params.blockId,
                                       params.gridPosition,
                                       params.gridPosition,
                                       0.0f);
    reg.emplace<TransformComponent>(entity, renderPos, 0.0f);
    reg.emplace<BoundsComponent>(entity, glm::vec3(0.5f));
    reg.emplace<GroundedStateComponent>(entity, GroundedStateComponent{false});
    reg.emplace<DropEntityIdComponent>(entity, dropId);
    reg.emplace<NetworkSyncTag>(entity);
    return entity;
}
```

**Minecraft 下落语义**:
- `gridPosition`: 逻辑格子位置（每 tick 下降一格）
- `TransformComponent.position`: 渲染位置（由 `FallingBlockInterpolateSystem` 插值）

#### 抛射物实体

```cpp
entt::entity EntityFactory::createProjectile(GameplayRegistry& registry,
                                             entt::entity owner,
                                             const glm::vec3& position,
                                             const glm::vec3& velocity,
                                             const ProjectileDefinition& definition) {
    const entt::entity projectile = reg.create();
    
    reg.emplace<ProjectileTag>(projectile);
    reg.emplace<ProjectileComponent>(projectile,
                                     owner,
                                     definition.damage,
                                     definition.hitRadius,
                                     definition.gravity,
                                     definition.entityImpactParticleBlock,
                                     definition.entityImpactParticleCount,
                                     definition.impactSoundId);
    reg.emplace<TransformComponent>(projectile, position, 0.0f);
    reg.emplace<VelocityComponent>(projectile, velocity);
    reg.emplace<ItemComponent>(projectile, definition.itemId, 1u);
    reg.emplace<BoundsComponent>(projectile, glm::vec3(definition.boundsHalfExtent));
    reg.emplace<LifetimeComponent>(projectile, 0.0f, definition.lifetimeSeconds);
    reg.emplace<SpinVisualComponent>(projectile, 0.0f, definition.spinSpeedRadians);
    reg.emplace<GroundedStateComponent>(projectile);
    reg.emplace<NetworkSyncTag>(projectile);
    return projectile;
}
```

**用途**: 投掷物品（如苹果）

### 实体销毁流程

#### 手动销毁

```cpp
ctx.registry.destroy(entity);  // 立即删除
```

#### 自动销毁

- **ItemLifetimeSystem**: 掉落物超过 30 秒自动销毁
- **DeathSystem**: 生命值归零后销毁（玩家除外）
- **ParticleCleanupSystem**: 粒子生命周期结束后销毁

#### 网络同步销毁

```cpp
// 客户端标记等待删除
reg.emplace<PendingNetworkDespawnTag>(entity);

// 服务器发送删除消息后才真正删除
```


---

## 客户端服务器分离

### Profile 机制

`GameplayPipeline` 在构造时接收 `GameplayPipelineProfile` 枚举：

```cpp
enum class GameplayPipelineProfile {
    Client,
    Server
};

GameplayPipeline::GameplayPipeline(GameplayPipelineProfile profile) {
    switch (profile) {
    case GameplayPipelineProfile::Client:
        buildClientFixedUpdateSystems();
        buildClientTickSystems();
        break;
    case GameplayPipelineProfile::Server:
        buildServerFixedUpdateSystems();
        break;
    }
}
```

### 客户端专有系统

**仅在客户端运行的系统**:

1. **InputSamplingSystem**: 采样本地输入设备
2. **PlayerIntentBuildSystem**: 构建玩家移动意图
3. **BlockTargetSystem**: 射线检测准星瞄准方块
4. **BlockBreakSystem**: 客户端预测方块破坏
5. **BlockPlaceSystem**: 客户端预测方块放置
6. **ParticleSpawnSystem**: 生成粒子实体
7. **ParticleSimulationSystem**: 粒子物理模拟
8. **ParticleCleanupSystem**: 清理过期粒子
9. **AudioSyncSystem**: 同步音频源到音频引擎
10. **PlayerFootstepAudioSystem**: 脚步声触发
11. **FallRollEffectSystem**: 着地相机翻滚效果
12. **ViewBobSystem**: 行走相机摇晃
13. **NetworkInterpolationSystem**: 快照插值
14. **SteveSyncSystem**: 同步人形模型部件位置
15. **SteveAnimationSystem**: 人形模型行走动画
16. **MobAnimationSystem**: 怪物动画
17. **TransformHierarchySystem**: 计算层级变换矩阵
18. **FallingBlockInterpolateSystem**: 下落方块渲染插值

### 服务器专有系统

**仅在服务器运行的系统**: 无（服务器是客户端的子集）

### 双端共享系统

**客户端和服务器都运行的系统**:

1. **MobAISystem**: 怪物 AI（服务器权威，客户端预测）
2. **CharacterPhysicsSystem**: 角色物理（服务器权威，客户端预测）
3. **PlayerMeleeSystem**: 近战攻击
4. **ProjectileSystem**: 抛射物物理
5. **DamageSystem**: 伤害应用
6. **HurtEffectDecaySystem**: 受伤效果衰减
7. **DeathSystem**: 死亡处理
8. **ItemPhysicsSystem**: 掉落物物理
9. **ItemMergeSystem**: 掉落物合并
10. **ItemPickupSystem**: 掉落物拾取
11. **ItemLifetimeSystem**: 掉落物生命周期

### 系统内 Profile 检测

某些系统在内部根据 Profile 调整行为：

```cpp
void BlockBreakSystem::update(SystemContext& ctx) {
    World* mutableWorld = ctx.services.world.get();
    
    if (mutableWorld == nullptr) {
        // 客户端模式：发送网络请求到服务器
        if (ctx.services.gameClient) {
            ctx.services.gameClient->sendBlockAction(action);
        }
    } else {
        // 服务器模式：直接修改世界
        mutableWorld->setBlock(hitBlock.x, hitBlock.y, hitBlock.z, 0);
        dropBus.push({brokenBlock, hitBlock});
    }
}
```

**判断依据**:
- `ctx.services.world.get() != nullptr`: 服务器模式（拥有可变 World）
- `ctx.services.gameClient.get() != nullptr`: 客户端模式（拥有 GameClient）

### 网络架构

#### 单机模式

```
GameSession
├── GameServer (owns World)
│   └── SaveManager
├── GameClient (reads ServerWorld via IWorldView)
└── GameplayScene (ECS, Profile::Client)
    └── services.world -> ServerWorld (read-only)
```

#### 多人模式

```
GameSession
├── GameClient
│   ├── ClientWorld (interpolated from server snapshots)
│   └── ENetTransport -> Remote Server
└── GameplayScene (ECS, Profile::Client)
    └── services.worldView -> ClientWorld (read-only)
```

**关键差异**:
- **单机**: ECS 直接读取服务器的 `World`（权威世界）
- **多人**: ECS 读取 `ClientWorld`（插值重建的世界）

### 客户端预测

客户端运行完整物理和逻辑，但结果不持久化：

1. **本地玩家**: 客户端预测移动和交互
2. **其他玩家**: 服务器快照插值
3. **怪物**: 客户端预测 AI（与服务器同步）
4. **掉落物**: 客户端预测物理（与服务器同步）

**冲突解决**: 服务器快照到达时，客户端直接接受权威位置（无回滚）

